
const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

app.use(cors());
app.use(express.static('public'));

let products = [
    { id: 1, name: "Laptop", description: "High performance laptop", image: "laptop.jpg" },
    { id: 2, name: "Smartphone", description: "Latest model smartphone", image: "smartphone.jpg" },
    { id: 3, name: "Headphones", description: "Noise-cancelling headphones", image: "headphones.jpg" },
    { id: 4, name: "Watch", description: "Smartwatch with fitness tracker", image: "watch.jpg" }
];

app.get('/api/products', (req, res) => {
    let query = req.query.query.toLowerCase();
    let filteredProducts = products.filter(product => product.name.toLowerCase().includes(query));
    res.json(filteredProducts);
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
