
let products = [
    { id: 1, name: "Laptop", description: "High performance laptop", image: "laptop.jpg" },
    { id: 2, name: "Smartphone", description: "Latest model smartphone", image: "smartphone.jpg" },
    { id: 3, name: "Headphones", description: "Noise-cancelling headphones", image: "headphones.jpg" },
    { id: 4, name: "Watch", description: "Smartwatch with fitness tracker", image: "watch.jpg" }
];

function searchProducts() {
    let query = document.getElementById('searchBar').value.toLowerCase();
    let filteredProducts = products.filter(product => product.name.toLowerCase().includes(query));

    displayResults(filteredProducts);
}

function displayResults(products) {
    let resultsContainer = document.getElementById('productResults');
    resultsContainer.innerHTML = "";

    products.forEach(product => {
        let productDiv = document.createElement('div');
        productDiv.classList.add('product');
        productDiv.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.description}</p>
        `;
        resultsContainer.appendChild(productDiv);
    });
}
